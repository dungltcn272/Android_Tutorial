package com.example.rxandroidandretrofit

class ObjectData (val title: String, val body: String)